const Employee=[
    {
        id:"1",
        Name:"surya",
        Age:"23",
        City:"vijayawada",
    },
    {
        id:"2",
        Name:"rohith",
        Age:"23",
        City:"Chennai",
    }
]

export default Employee;
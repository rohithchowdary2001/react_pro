// import './App.css';

// function App() {
//     (
//      <>
//   <div className='container'>
   
//     <form>
//       <div className="details">
//         <h4 className='head'><u>Login</u></h4>
//         <div className='username'>
//         <label >Email/User Name </label>
//         <input type="email"  placeholder='Enter User Details' required/>
//         </div>
//         <br/>
//         <div className='password'>
//         <label>Password  </label>
//         <input type='password' placeholder='Enter Password'/>
//         </div>
//         <br/>
//         <div>
//         <button className='hii' >Login</button>
//         </div>
        
//       </div>
//     </form>
//   </div>
//   <input type = "button" value = "Click me" />  
//   </>

//   );
// }

// export default App;

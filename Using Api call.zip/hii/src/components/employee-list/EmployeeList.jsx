import React from 'react';
 import './EmployeeList.css';
 import { useNavigate } from 'react-router';
 import Edit from '../Edit';

class EmployeeList extends React.Component {

  
  constructor() {
    super();
    this.state = {
      users: null,
    };
  }

  componentDidMount() {
    fetch('https://api.randomuser.me/?nat=US&results=20').then((response) => {
      response.json().then((result) => {
        // console.warn(result.data);
        this.setState({ users:result.results });
      });
    });
  }
  
  render() {
    return (
      <div>

<table>
  <tr>
    <th>No.</th>
    <th>ID</th>
    <th>NAME</th>
    <th>SEX</th>
    <th>EMAIL</th>
    <th>AGE</th>
    {/* <th>SALARY</th>
    <th>DEPARTMENT</th> */}
  </tr>
  
  {this.state.users
          ? this.state.users.map((item, i) => (
            <>
              <tr>
                <td>  {i+1} {' '}</td>
                <td>  {item.id.name} {' '}</td>
                <td>  {item.name.first} {item.name.last}{' '}</td>
                <td>  {item.gender} {' '}</td>
                <td>  {item.email} {' '}</td>
                <td>  {item.registered.age} {' '}</td>
                {/* <td>  {''} {' '}</td>
                <td>  {''} {' '}</td> */}
                {/* <td>  <button>Edit</button></td>
                <td>  <button>Delete</button></td> */}
                <td><a class="btn btn-primary" href="/Edit" role="button">Edit</a></td>
                <td><a class="btn btn-primary" href="#" role="button">Delete</a></td>


                </tr>
            </>
           
            ))
          : null}


</table>

        
      </div>
    );
  }
}

export default EmployeeList;
